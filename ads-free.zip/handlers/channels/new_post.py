from aiogram import types
from utils.db_api import quick_commands as commands
from loader import dp, bot


@dp.channel_post_handler(content_types=types.ContentType.ANY)
async def new_post(message: types.Message):
    channel = await commands.select_channel(id=message.chat.id)
    user = await commands.select_user(id=channel.ownerid)
    print(message.message_id)


    if user.text == None:
        await bot.send_message(disable_notification=True, chat_id=message.chat.id, text=f"Эта плашка будет здесь до тех пор, пока Телеграм не отключит рекламу у меня на канале, я буду перепубликовывать ее без нотификации после каждого поста.\n\n"
                                                                                    f"👇 <i>В посте ниже (если он есть) — мошенники, ни в коем случае не подписывайтесь 👇</i>")
        await commands.update_postid(id=message.chat.id, postid=message.message_id)
    else:
        await bot.send_message(disable_notification=True, chat_id=message.chat.id, text=user.text)
        await commands.update_postid(id=message.chat.id, postid=message.message_id)

    if message.message_id < channel.postid:
        pass
    else:
        await bot.delete_message(chat_id=channel.id, message_id=int(channel.postid)+1)
