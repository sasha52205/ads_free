from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart

from keyboards.inline.menu import menu_kb
from loader import dp
from utils.db_api import quick_commands as commands


@dp.message_handler(CommandStart())
async def bot_start(message: types.Message):
    name = message.from_user.full_name
    await commands.add_user(id=message.from_user.id,
                            name=name)
    await message.answer(
        f'Привет, {message.from_user.full_name}\n\n'
        f'С помощью данного бота, ты сможешь добавить плашку - под каждый пост канала.🐱\n'
        f'<i>Например, для предупреждения подписчиков о рекламе</i>\n\n\n'
        f'<b>Инструкция по настройке:</b>\n\n'
        f'1.Добавь бота - в нужный канал\n'
        f'2.Предоставь боту права администратора\n'
        f'3.Перешли любой пост с канала данному боту\n\n'
        f'Поздравляю, теперь все работает🔥\n',reply_markup = menu_kb)
