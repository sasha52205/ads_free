from aiogram import types

from filters import IsForwarded
from loader import dp
from utils.db_api import quick_commands as commands


@dp.message_handler(IsForwarded(), content_types=types.ContentType.ANY)
async def get_channel_info(message: types.Message):
    await message.answer(f"Сообщение прислано из канала {message.forward_from_chat.title}. \n"
                         f"Username: @{message.forward_from_chat.username}\n"
                         f"ID: {message.forward_from_chat.id}\n\n"
                         f"<b>>Не забудьте дать боту права администратора!</b>\n\n"
                         f"Бот успешно добавлен и работает (при наличии прав админситратора)")
    await commands.add_channel(id=message.forward_from_chat.id, name=message.forward_from_chat.title, ownerid=message.from_user.id)