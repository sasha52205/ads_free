from .help import dp
from .start import dp
from .update_db import dp
from .add_channel import dp
from .menu import dp

__all__ = ["dp"]
