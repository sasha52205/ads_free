from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Command

from aiogram.types import CallbackQuery, Message

from handlers.users import start
from keyboards.inline.menu import ans_kb, menu_kb, close_kb
from loader import dp
from utils.db_api import quick_commands as commands


@dp.callback_query_handler(text_contains="info")
async def buying_pear(call: CallbackQuery):
    await call.message.answer(f'<b>Инструкция по настройке:</b>\n\n'
                              f'1.Добавь бота - в нужный канал\n'
                              f'2.Предоставь боту права администратора\n'
                              f'3.Перешли любой пост с канала данному боту\n\n'
                              f'Поздравляю, теперь все работает🔥\n\n\n'
                              f'А так же видно инструкция и демонстрация работы')
    await call.answer()

    @ dp.callback_query_handler(text_contains="change_text")
    async def buying_pear(call: CallbackQuery):
        user = await commands.select_user(id=call.from_user.id)
        if user.text == None:
            text = (
                f'Эта плашка будет здесь до тех пор, пока Телеграм не отключит рекламу у меня на канале, я буду перепубликовывать ее без нотификации после каждого поста.\n\n'
                f'👇 <i>В посте ниже (если он есть) — мошенники, ни в коем случае не подписывайтесь</i> 👇')
        else:
            text = user.text
        await call.message.answer(f"На данный момент текст сообщения:\n\n"
                                  f"{text}\n\n"
                                  f"<b>Хотите изменить данный текст?</b>", reply_markup=ans_kb)
        await call.answer()

    @dp.callback_query_handler(text_contains="change_text")
    async def buying_pear(call: CallbackQuery):
        user = await commands.select_user(id=call.from_user.id)
        if user.text == None:
            text = (
                f'Эта плашка будет здесь до тех пор, пока Телеграм не отключит рекламу у меня на канале, я буду перепубликовывать ее без нотификации после каждого поста.\n\n'
                f'👇 <i>В посте ниже (если он есть) — мошенники, ни в коем случае не подписывайтесь</i> 👇')
        else:
            text = user.text
        await call.message.answer(f"На данный момент текст сообщения:\n\n"
                                  f"{text}\n\n"
                                  f"<b>Хотите изменить данный текст?</b>", reply_markup=ans_kb)
        await call.answer()

    @dp.callback_query_handler(text="yes")
    async def cancel_buying(call: CallbackQuery, state: FSMContext):
        await call.answer()
        await call.message.answer("Пришлите мне новый текст.")
        await state.set_state('new_text')

    @dp.message_handler(state='new_text')
    async def answer_q1(message: Message, state: FSMContext):
        answer = message.text
        await commands.update_text(id=message.from_user.id, text=answer)
        await message.answer(f"Текст успешно изменен на:\n\n"
                             f"{answer}", reply_markup=menu_kb)
        await state.finish()

    @dp.callback_query_handler(text="cancel")
    async def cancel_buying(call: CallbackQuery, state: FSMContext):
        # Ответим в окошке с уведомлением!
        await call.answer("Вы отменили данное действие!", show_alert=True)
        await call.message.delete()
        await state.finish()

    @dp.callback_query_handler(text="donate")
    async def cancel_buying(call: CallbackQuery, state: FSMContext):
        await call.answer()
        await call.message.answer(f'Бот полностью бесплатный, но при желании можно поддерживать автора🐱\n\n'
                                  f'Для связи - @Tele_geek\n\n'
                                  f'Реквизиты:\n\n'
                                  f'<code>4890 4947 5912 9240</code>', reply_markup=close_kb)



@dp.message_handler(Command("count"), state=None)
async def enter_test(message: Message):
    count = await commands.count_users()
    await message.answer(f'Сейчас в боте: <b>{count}</b> пользователей')
