from .errors import dp
from .channels import dp
from .users import dp

__all__ = ["dp"]
