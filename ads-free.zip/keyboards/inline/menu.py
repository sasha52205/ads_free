
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup



menu_kb = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(text="Инструкция", callback_data='info'),
    ],
    [
        InlineKeyboardButton(text="Изменить текст", callback_data="change_text")
    ],
    [
        InlineKeyboardButton(text="Подержать автора", callback_data="donate")
    ]
])

ans_kb = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(text="Да", callback_data='yes'),
    ],
    [
        InlineKeyboardButton(text="Нет", callback_data="cancel")
    ],
])
close_kb = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(text="Закрыть", callback_data='cancel'),
    ]
])
