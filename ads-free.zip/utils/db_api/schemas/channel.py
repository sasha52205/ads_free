from sqlalchemy import Integer, Column, BigInteger, String, sql

from utils.db_api.db_gino import TimedBaseModel


class Channel(TimedBaseModel):
    __tablename__ = 'channels'
    id = Column(BigInteger, primary_key=True)
    name = Column(String(100))
    postid = Column(BigInteger)
    ownerid =  Column(BigInteger)




    query: sql.Select
