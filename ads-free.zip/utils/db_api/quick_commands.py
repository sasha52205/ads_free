from asyncpg import UniqueViolationError

from utils.db_api.db_gino import db
from utils.db_api.schemas.channel import Channel
from utils.db_api.schemas.user import User


async def add_user(id: int, name: str, text: str = None):
    try:
        user = User(id=id, name=name, text=text)
        await user.create()

    except UniqueViolationError:
        pass



async def select_all_users():
    users = await User.query.gino.all()
    return users


async def select_user(id: int):
    user = await User.query.where(User.id == id).gino.first()
    return user


async def count_users():
    total = await db.func.count(User.id).gino.scalar()
    return total


async def update_text(id, text):
    user = await User.get(id)
    await user.update(text=text).apply()


##################
async def add_channel(id: int, name: str, ownerid:int, postid: int=0):
    try:
        channel = Channel(id=id, name=name, ownerid=ownerid, postid=postid )
        await channel.create()

    except UniqueViolationError:
        pass


async def update_postid(id, postid):
    channel = await Channel.get(id)
    await channel.update(postid=postid).apply()

async def select_channel(id: int):
    channel = await Channel.query.where(Channel.id == id).gino.first()
    return channel